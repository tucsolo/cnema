# Moonloop
Multi-channel-chat client/server application for *NIX
